module.exports = {
  BOT_TOKEN: "TOKENS",
};